import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jokes',
  templateUrl: './jokes.component.html',
  styleUrls: ['./jokes.component.scss']
})
export class JokesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
