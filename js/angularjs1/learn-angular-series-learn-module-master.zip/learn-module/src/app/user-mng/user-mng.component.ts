import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'user-mng',
  templateUrl: './user-mng.component.html',
  styleUrls: ['./user-mng.component.scss']
})
export class UserMngComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
