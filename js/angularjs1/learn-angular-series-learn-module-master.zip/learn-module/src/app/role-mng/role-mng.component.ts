import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'role-mng',
  templateUrl: './role-mng.component.html',
  styleUrls: ['./role-mng.component.scss']
})
export class RoleMngComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
